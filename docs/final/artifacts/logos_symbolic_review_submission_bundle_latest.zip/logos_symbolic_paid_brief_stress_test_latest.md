# Logos Paid Brief Stress Test

- generated_at_utc: `2026-05-05T12:49:14Z`
- status: `ok`
- scenario_count: `3`
- fail_count: `0`

## Scenario Results
- `hormuz_oil_shock`: WATCH->HOLD, confidence 100->80, guardrail_ok=True
- `fed_hawkish_surprise`: WATCH->HOLD, confidence 100->80, guardrail_ok=True
- `etf_flow_reversal`: WATCH->WATCH, confidence 100->90, guardrail_ok=True

## Verdict
- 충격 시나리오에서도 보수화 로직 및 가드레일 유지 확인.
