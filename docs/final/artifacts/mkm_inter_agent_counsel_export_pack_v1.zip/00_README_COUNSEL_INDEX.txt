MKM RQ-019 Inter-Agent Encoding — counsel review pack
generated_at_utc: 2026-05-18T22:29:10Z
file_count: 16
manifest: docs/final/artifacts/mkm_inter_agent_counsel_export_manifest_v1_latest.json
NOT legal sign-off. INTERNAL review only until counsel approval recorded.
